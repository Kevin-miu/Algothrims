import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class Permutation {
        
    public static void main(String[] args) {
        // get k from command line argument
        int k = Integer.parseInt(args[0]);

        // corner case: no-op when k <= 0
        if (k <= 0) return;

        // Initialize RQ
        RandomizedQueue<String> rq = new RandomizedQueue<String>();

        // number of Strings processed
        double count = 0.0;

        // main loop
        while (!StdIn.isEmpty()) {
            // read a new string from standard input and bump the counter
            String str = StdIn.readString();
            count++;

            // tricky part for the bonus:
            if (rq.size() >= k) {
                if (StdRandom.uniform() < (count - k) / count) continue;
                else rq.dequeue();
            }
            
            // enqueue the new string
            rq.enqueue(str);
        }

        // output results
        for (int i = 0; i < k; ++i) 
            StdOut.println(rq.dequeue());
    }
}
