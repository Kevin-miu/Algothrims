import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

/**
 * 使用可调整大小的数组来实现resizing array
 * 
 * @author Kevin-
 * @date 2018年9月3日
 *
 * @param <Item>
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

	private Item[] arrays;
	private int N;

	public RandomizedQueue() {
		arrays = (Item[]) new Object[1];
		N = 0;
	}

	// isEmpty()判断随机队列是否为空
	public boolean isEmpty() {
		return N == 0;
	}

	// size()获取随机队列的长度
	public int size() {
		return N;
	}

	// enqueue()新元素插入随机队列尾
	public void enqueue(Item item) {
		if (item == null) {
			throw new IllegalArgumentException("item can not be null.");
		}

		if (N == arrays.length) {
			resize(arrays.length * 2);
		}

		arrays[N++] = item;

	}

	// dequeue()随机选取一个元素出队
	public Item dequeue() {
		if (isEmpty()) {
			throw new NoSuchElementException("the randomized queue is empty.");
		}

		swapArrays();
		Item randomItem = arrays[--N];
		arrays[N] = null;

		if (N > 0 && N == (arrays.length / 4)) {
			resize(arrays.length / 2);
		}

		return randomItem;
	}

	// sample()随机选取一个元素
	public Item sample() {
		if (isEmpty()) {
			throw new NoSuchElementException("the randomized queue is empty.");
		}

		int randomId = StdRandom.uniform(N);

		return arrays[randomId];
	}

	@Override
	public Iterator<Item> iterator() {
		return new RQIterator();
	}

	// resize()调整数组的长度
	private void resize(int size) {

		Item[] newArrays = (Item[]) new Object[size];

		for (int i = 0; i < size / 2; i++) {
			newArrays[i] = arrays[i];
		}
		arrays = newArrays;
	}

	// 将随机选取的数组元素交换到队尾
	private void swapArrays() {

		int randomId = StdRandom.uniform(N);
		Item temp = arrays[randomId];
		arrays[randomId] = arrays[N - 1];
		arrays[N - 1] = temp;
	}

	private class RQIterator implements Iterator<Item> {
		// 预先产生随机数数组
		private final int[] randomIds = StdRandom.permutation(N);
		private int i = N;

		@Override
		public boolean hasNext() {
			return i > 0;
		}

		@Override
		public Item next() {
			if (!hasNext()) {
				throw new NoSuchElementException("the randomized queue is empty.");
			}

			return arrays[randomIds[--i]];
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException("not support this method.");
		}

	}

	// 单元测试
	public static void main(String[] args) {

		RandomizedQueue<Integer> RQueue = new RandomizedQueue<>();

		for (int i = 0; i < 20; i++) {
			RQueue.enqueue(i);
		}

		StdOut.println("修改前 size: " + RQueue.size());
		Iterator<Integer> it = RQueue.iterator();
		while (it.hasNext()) {
			StdOut.print(it.next() + " ");
		}
		StdOut.println();

		for (int i = 0; i < 10; i++) {
			RQueue.dequeue();
		}

		StdOut.println("修改后 size: " + RQueue.size());
		it = RQueue.iterator();
		while (it.hasNext()) {
			StdOut.print(it.next() + " ");
		}
		StdOut.println();
		StdOut.println("是否为空： " + RQueue.isEmpty());

	}

}
