import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdOut;

/**
 * 使用双向链表链实现 double linked list
 * 
 * @author Kevin-
 * @date 2018年9月3日
 *
 * @param <Item>
 */
public class Deque<Item> implements Iterable<Item> {

	private Node first;
	private Node last;
	private final Node nil;

	private int N;

	// 构造一个空的双向队列
	public Deque() {
		nil = new Node(null, null, null);
		first = nil;
		last = nil;
		N = 0;
	}

	// isEmpty()判空操作
	public boolean isEmpty() {
		return first.item == null && last.item == null;
	}

	// size()获取队列的大小
	public int size() {
		return N;
	}

	// addFirst()添加元素到队列头
	public void addFirst(Item item) {

		// 输入参数不能为空
		if (item == null) {
			throw new IllegalArgumentException("item can not be null");
		}

		Node newFirst = new Node(item, first, nil);

		// 如果是添加第一个元素，则要将first和last同时指向该元素
		if (isEmpty()) {
			last = newFirst;
			first = newFirst;
		} else {
			first.pre = newFirst;
			first = newFirst;
		}
		N++;
	}

	// addLast()添加元素到队列尾
	public void addLast(Item item) {

		// 输入参数不能为空
		if (item == null) {
			throw new IllegalArgumentException("item can not be null");
		}

		Node newLast = new Node(item, nil, last);

		// 如果是第一个元素，则要将first和last同时指向该元素
		if (isEmpty()) {
			first = newLast;
			last = newLast;

		} else {
			// 注意将链表连接起来
			last.next = newLast;
			last = newLast;
		}
		N++;
	}

	// removeFirst()从队列头移除元素
	public Item removeFirst() {

		// 如果链表为空
		if (isEmpty()) {
			throw new NoSuchElementException("linked list is empty");
		}

		Item item = first.item;
		first = first.next;
		if (first.item == null) {
			last = nil;
		} else {
			first.pre = nil;
		}

		N--;
		return item;
	}

	// removeLast()从队列尾移除元素
	public Item removeLast() {

		// 如果链表为空
		if (isEmpty()) {
			throw new NoSuchElementException("linked list is empty");
		}

		Item item = last.item;
		last = last.pre;
		if (last.item == null) {
			first = nil;
		} else {
			last.next = nil;
		}

		N--;
		return item;
	}

	@Override
	public Iterator<Item> iterator() {
		return new DLLIterator();
	}

	// 双向链表节点
	private class Node {
		Item item;
		Node next;
		Node pre;

		public Node(Item item, Node next, Node pre) {
			this.item = item;
			this.next = next;
			this.pre = pre;
		}
	}

	// 自定义双向链表的迭代器
	private class DLLIterator implements Iterator<Item> {

		private Node current = first;

		@Override
		public boolean hasNext() {
			return current.next != null;
		}

		@Override
		public Item next() {
			if (!hasNext()) {
				throw new NoSuchElementException("linked list is empty.");
			}
			Item item = current.item;
			current = current.next;
			return item;
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException("not support this method.");
		}

	}

	// 单元测试
	public static void main(String[] args) {

		Deque<Integer> deque = new Deque<>();

		for (int i = 0; i < 10; i++) {
			deque.addFirst(i);
			deque.addLast(i);
		}

		StdOut.println("修改前 size: " + deque.size());
		Iterator<Integer> it = deque.iterator();

		while (it.hasNext()) {
			StdOut.print(it.next() + " ");
		}
		StdOut.println();

		for (int i = 0; i < 5; i++) {
			deque.removeFirst();
			deque.removeLast();
		}
		StdOut.println("修改后 size: " + deque.size());

		it = deque.iterator();
		while (it.hasNext()) {
			StdOut.print(it.next() + " ");
		}
		StdOut.println();
		StdOut.println("是否为空 " + deque.isEmpty());
	}
}
