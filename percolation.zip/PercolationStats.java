import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.Stopwatch;

public class PercolationStats {

	private final static double NUM = 1.96;

	private double[] fractions; // 每一次实验的渗透率得分
	private int trials = 0;

	private double meanNum = 0;
	private double stddevNum = 0;
	private double confidenceLoNum = 0;
	private double confidenceHiNum = 0;

	/**
	 * 构造方法
	 * 
	 * @param n
	 *            n*n数组的维度
	 * @param trials
	 *            实验次数
	 */
	public PercolationStats(int n, int trials) {

		if (n <= 0 || trials <= 0) {
			throw new IllegalArgumentException("n:" + n + " or trials:" + trials + " is invalid.");
		}

		fractions = new double[trials];
		this.trials = trials;

		for (int k = 0; k < trials; k++) {

			fractions[k] = calFraction(n);
		}

	}

	// 计算每次实验的渗透率得分
	private double calFraction(int n) {

		Percolation percolation = new Percolation(n);
		double count = 0;
		while (!percolation.percolates()) {
			int i = StdRandom.uniform(1, n + 1);
			int j = StdRandom.uniform(1, n + 1);

			if (percolation.isOpen(i, j)) {
				continue;
			}
			percolation.open(i, j);
			count++;
		}

		return count / (n * n);
	}

	// 计算平均数
	public double mean() {
		meanNum = StdStats.mean(fractions);
		return meanNum;
	}

	// 计算标准差
	public double stddev() {
		stddevNum = StdStats.stddev(fractions);
		return stddevNum;
	}

	// 计算区间下限
	public double confidenceLo() {
		confidenceLoNum = meanNum - (NUM * stddevNum) / Math.sqrt(trials);
		return confidenceLoNum;
	}

	// 计算区间上限
	public double confidenceHi() {
		confidenceHiNum = meanNum + (NUM * stddevNum) / Math.sqrt(trials);
		return confidenceHiNum;
	}

	// 主方法
	public static void main(String[] args) {

		int n = Integer.parseInt(args[0]);
		int trials = Integer.parseInt(args[1]);
		Stopwatch stopwatch = new Stopwatch();

		PercolationStats stats = new PercolationStats(n, trials);
		StdOut.println("time costed:                    " + stopwatch.elapsedTime() + "s");

		StdOut.println("mean:			         " + stats.mean());
		StdOut.println("stddev:			         " + stats.stddev());
		StdOut.println("95% confidence interval: [ " + stats.confidenceLo() + " , " + stats.confidenceHi() + " ]");

	}

}
