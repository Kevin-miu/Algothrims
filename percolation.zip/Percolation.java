import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	// 分别表示BLOCK和OPEN状态
	private static final boolean BLOCK = false;
	private static final boolean OPEN = true;

	private WeightedQuickUnionUF topUF, bottomUF;
	private int openedNum = 0;
	private boolean percolationFlag = false;
	private int n = 0;
	private boolean[][] grid;

	// 构造函数，创建n个blocked的数据块
	public Percolation(int n) {

		if (n < 0) {
			throw new IllegalArgumentException("n: " + n + " is invalid.");
		}

		this.n = n;
		topUF = new WeightedQuickUnionUF(n * n + 1);
		bottomUF = new WeightedQuickUnionUF(n * n + 1);
		grid = new boolean[n][n];

		// 初始化grid设置为BLOCK
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				grid[i][j] = BLOCK;
			}
		}

	}

	// 检验输入的行列是否越界
	private void validate(int row, int col) {
		if (row < 1 || row > n || col < 1 || col > n) {
			throw new IllegalArgumentException("input row or col is not illegal!");
		}
	}

	// open一个状态是blocked的块
	public void open(int row, int col) {

		validate(row, col);
		if (isOpen(row, col)) {
			return;
		}

		grid[row - 1][col - 1] = OPEN;
		openedNum++;

		// 只有一个点的时候
		if (n == 1) {
			topUF.union(0, 1);
			bottomUF.union(0, 1);
			percolationFlag = true;
			return;
		}

		// 第一行的所有节点与top虚节点连通
		if (row == 1) {
			topUF.union(n * n, col - 1);
		}

		// 最后一行的所有节点与bottom虚节点连通
		if (row == n) {
			bottomUF.union(n * n, (n - 1) * n + (col - 1));
		}

		// 与上方节点的连通性(要防止越界)
		if (row > 1 && grid[row - 2][col - 1] == OPEN) {
			topUF.union((row - 1) * n + (col - 1), (row - 2) * n + (col - 1));
			bottomUF.union((row - 1) * n + (col - 1), (row - 2) * n + (col - 1));
		}

		// 与下方节点的连通性
		if (row < n && grid[row][col - 1] == OPEN) {
			topUF.union((row - 1) * n + (col - 1), row * n + (col - 1));
			bottomUF.union((row - 1) * n + (col - 1), row * n + (col - 1));
		}

		// 与左方节点的连通性
		if (col > 1 && grid[row - 1][col - 2] == OPEN) {
			topUF.union((row - 1) * n + (col - 1), (row - 1) * n + (col - 2));
			bottomUF.union((row - 1) * n + (col - 1), (row - 1) * n + (col - 2));
		}

		// 与右方节点的连通性
		if (col < n && grid[row - 1][col] == OPEN) {
			topUF.union((row - 1) * n + (col - 1), (row - 1) * n + col);
			bottomUF.union((row - 1) * n + (col - 1), (row - 1) * n + col);
		}

		// 判断此次open之后，是否可以渗透
		// 1.只有open的块数大于n，才有可能渗透
		// 2.此前是没有渗透的
		// 3.虚拟top和bottom相连了
		if (openedNum >= n && !percolationFlag && topUF.connected(n * n, (row - 1) * n + (col - 1))
				&& bottomUF.connected(n * n, (row - 1) * n + (col - 1))) {
			percolationFlag = true;
		}

	}

	// 判断一个块是否open
	public boolean isOpen(int row, int col) {

		validate(row, col);

		return grid[row - 1][col - 1] == OPEN;
	}

	// 判断一个块是否连通到top
	public boolean isFull(int row, int col) {

		validate(row, col);

		if (isOpen(row, col) && topUF.connected(n * n, (row - 1) * n + (col - 1))) {
			return true;
		} else {
			return false;
		}
	}

	// 状态是opened的块的做总数
	public int numberOfOpenSites() {

		return openedNum;
	}

	// 系统是否percolate(可渗透)
	public boolean percolates() {

		return percolationFlag;
	}

	// 主函数
	public static void main(String[] args) {

		In in = new In(args[0]);
		int num = in.readInt();

		Percolation percolation = new Percolation(num);
		int count = 0;

		while (!in.isEmpty()) {
			int i = in.readInt();
			int j = in.readInt();

			if (!percolation.isOpen(i, j)) {
				count++;
				percolation.open(i, j);
			}
			if (percolation.percolates()) {
				break;
			}
		}

		StdOut.println(count + " open sites.");

	}

}
