import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class FastCollinearPoints {
	private ArrayList<LineSegment> lineSegmentList;

	public FastCollinearPoints(Point[] points) {

		if (points == null) {
			throw new IllegalArgumentException("parameter error!");
		}

		int len = points.length;
		for (int i = 0; i < len; i++) {
			if (points[i] == null) {
				throw new IllegalArgumentException("parameter error!");
			}
		}

		for (int i = 0; i < len; ++i) {
			for (int j = i + 1; j < len; ++j) {
				if (points[i].compareTo(points[j]) == 0) {
					throw new IllegalArgumentException("parameter error!");
				}
			}
		}

		Point[] ps = points.clone();
		Arrays.sort(ps);

		// 当前参考节点
		Point currentPoint;
		// Point[] otherPoints = new Point[len - 1];

		lineSegmentList = new ArrayList<>();

		for (int i = 0; i < len; i++) {

			Point[] p = ps.clone();
			currentPoint = p[i];

			// 根据斜率对点排序
			Arrays.sort(p, currentPoint.slopeOrder());

			// 两点必有直线，所以num初始为2
			int num = 2;
			// 排序后的ps数组第一位就是参考节点本身，需要排除
			for (int k = 2; k < len; k++) {
				double slop1 = p[k - 1].slopeTo(currentPoint);
				double slop2 = p[k].slopeTo(currentPoint);

				if (Double.compare(slop1, slop2) == 0) {
					num++;
					// 此时循环到最后最后一个点，同时该点与前面的点共线(共线的点一定是连续的)
					if (k == len - 1) {
						// 如果有4点及以上共线，且otherPoints中与参考点共线且排在最左边的点比参考点大的话
						// 注意compareTo方法可以避免重复线段
						if (num >= 4 && currentPoint.compareTo(p[k - num + 2]) < 0) {
							Point start = currentPoint;
							Point end = p[k];
							lineSegmentList.add(new LineSegment(start, end));
						}
					}
				} else {
					// 只要连续的点斜率不同，则说明不可能在再共线
					if (num >= 4 && currentPoint.compareTo(p[k - num + 1]) < 0) {
						Point start = currentPoint;
						Point end = p[k - 1];
						lineSegmentList.add(new LineSegment(start, end));
					}
					num = 2;
				}
			}
		}

	}

	public int numberOfSegments() {

		return lineSegmentList.size();
	}

	public LineSegment[] segments() {

		LineSegment[] lineSegments = new LineSegment[lineSegmentList.size()];
		int index = 0;

		for (LineSegment line : lineSegmentList) {
			lineSegments[index++] = line;
		}

		return lineSegments;
	}

	public static void main(String[] args) {

		In in = new In(args[0]);
		int n = in.readInt();

		Point[] points = new Point[n];
		for (int i = 0; i < n; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x, y);
		}

		// draw the points
		StdDraw.enableDoubleBuffering();
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);
		for (Point p : points) {
			p.draw();
		}
		StdDraw.show();

		// print and draw the line segments
		FastCollinearPoints collinear = new FastCollinearPoints(points);
		for (LineSegment segment : collinear.segments()) {
			StdOut.println(segment);
			segment.draw();
		}
		StdDraw.show();
	}

}
