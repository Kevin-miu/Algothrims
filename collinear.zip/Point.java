import java.util.Arrays;
import java.util.Comparator;

import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class Point implements Comparable<Point> {
    private final int x;
	private final int y;

	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	// 在平面上画点
	public void draw() {

		StdDraw.point(x, y);
	}

	// 在两点之间画线
	public void drawTo(Point that) {
		if (that == null) {
			throw new NullPointerException("argument is null");
		}

		StdDraw.line(this.x, this.y, that.x, that.y);
	}

	public String toString() {
		return "(" + x + " , " + y + ")";
	}

	@Override
	public int compareTo(Point that) {
		if (that == null) {
			throw new NullPointerException("argument is null");
		}

		if (this.y < that.y || (this.y == that.y && this.x < that.x)) {
			return -1;
		} else if (this.y == that.y && this.x == that.x) {
			return 0;
		} else {
			return 1;
		}
	}

	public double slopeTo(Point that) {

		if (that == null) {
			throw new NullPointerException("argument is null");
		}

		if (this.x == that.x && this.y == that.y) {
			// 与它本身
			return Double.NEGATIVE_INFINITY;
		}
		if (this.x == that.x && this.y != that.y) {
			// 垂直
			return Double.POSITIVE_INFINITY;
		}
		if (this.y == that.y) {
			// 水平
			return 0.0;
		}
		return (double) (this.y - that.y) / (this.x - that.x);

	}

	public Comparator<Point> slopeOrder() {
		return new SlopComparator();
	}

	private class SlopComparator implements Comparator<Point> {

		@Override
		public int compare(Point o1, Point o2) {

			double slop1 = slopeTo(o1);
			double slop2 = slopeTo(o2);
			if (slop1 > slop2) {
				return 1;
			} else if (slop1 < slop2) {
				return -1;
			} else {
				return 0;
			}
		}

	}

	public static void main(String[] args) {
		Point[] points = new Point[10];
		for (int i = 0; i < 10; i++) {
			points[i] = new Point(i, i * i - 10 * i + 25);
		}
		StdOut.print("before sort : ");
		for (int i = 0; i < 10; i++) {
			StdOut.print(points[i].toString() + " ");
		}
		StdOut.println();

		StdOut.print("slop to (0,i)：");
		for (int i = 0; i < 10; i++) {
			StdOut.print(points[i].slopeTo(new Point(0, i * i)) + " ");
		}
		StdOut.println();

		Arrays.sort(points, points[5].slopeOrder());
		StdOut.print("after sort: ");
		for (int i = 0; i < 10; i++) {
			StdOut.print(points[i].toString() + " ");
		}
		StdOut.println();

	}

}
