import java.util.Arrays;
import java.util.Iterator;
import java.util.Stack;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class Board {

	private int dimen;
	private int[][] block;

	public Board(int[][] block) {

		if (block == null) {
			throw new IllegalArgumentException("block is null!");
		}

		this.dimen = block.length;
		this.block = new int[dimen][dimen];

		// 如果使用一维数组来操作会更加方便
		for (int i = 0; i < this.dimen; i++) {
			for (int j = 0; j < this.dimen; j++) {
				this.block[i][j] = block[i][j];
			}
		}
	}

	public int dimension() {
		return dimen;
	}

	// hamming priority function
	public int hamming() {

		int hamming = 0;

		for (int i = 0; i < dimen; i++) {
			for (int j = 0; j < dimen; j++) {
				if (block[i][j] != 0 && block[i][j] != i * dimen + j + 1) {
					hamming++;
				}
			}
		}

		return hamming;
	}

	// manhattan priority function
	public int manhattan() {

		int manhattan = 0;

		for (int i = 0; i < dimen; i++) {
			for (int j = 0; j < dimen; j++) {

				if (block[i][j] != 0) {

					int x = (block[i][j] - 1) / dimen;// 求行
					int y = (block[i][j] - 1) % dimen;// 求列
					manhattan += Math.abs(x - i) + Math.abs(y - j);
				}
			}
		}

		return manhattan;
	}

	public boolean isGoal() {
		return hamming() == 0;
	}

	// 任意交换一个block，用于判断是否有解
	public Board twin() {

		int[][] newBlock;

		if (block[0][0] != 0 && block[0][1] != 0) {
			newBlock = exchBlock(0, 0, 0, 1);
		} else {
			newBlock = exchBlock(dimen - 1, dimen - 2, dimen - 1, dimen - 1);
		}

		return new Board(newBlock);
	}

	// 判断两个block是否相等
	public boolean equals(Object y) {

		if (y == null) {
			return false;
		}
		if (y == this) {
			return true;
		}
		if (y.getClass() != this.getClass()) {
			return false;
		}

		Board yBoard = (Board) y;

		if (yBoard.dimension() != this.dimension()) {
			return false;
		}

		for (int i = 0; i < dimen; i++) {
			for (int j = 0; j < dimen; j++) {
				if (yBoard.block[i][j] != this.block[i][j]) {
					return false;
				}
			}
		}

		return true;
	}

	// 找到与本serach node相邻的块并入队\栈
	public Iterable<Board> neighbors() {

		Stack<Board> neighbors = new Stack<>();
		int[] diff = { -1, 1 };
		int[][] newBlock;

		int blankOfi = 0;
		int blankOfj = 0;

		// 找到0所在的位置blank squar
		for (int i = 0; i < dimen; i++) {
			for (int j = 0; j < dimen; j++) {
				if (block[i][j] == 0) {
					blankOfi = i;
					blankOfj = j;
					break;
				}
			}
		}

		// 将blank squar位置与其相邻位置交换，得到邻居borad

		for (int i = 0; i < diff.length; i++) {
			int m = blankOfj + diff[i];
			if (m < 0 || m >= dimen) {
				continue;
			}

			newBlock = exchBlock(blankOfi, blankOfj, blankOfi, m);
			neighbors.push(new Board(newBlock));
		}

		for (int i = 0; i < diff.length; i++) {
			int m = blankOfi + diff[i];
			if (m >= 0 && m < dimen) {

				newBlock = exchBlock(blankOfi, blankOfj, m, blankOfj);

				neighbors.push(new Board(newBlock));
			}
		}

		return neighbors;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();

		builder.append(dimen + "\n");
		for (int i = 0; i < dimen; i++) {
			for (int j = 0; j < dimen; j++) {
				builder.append(String.format("%2d ", block[i][j]));
			}
			builder.append("\n");
		}

		return builder.toString();
	}

	// 交换指定的block块
	private int[][] exchBlock(int i1, int j1, int i2, int j2) {

		int[][] newBlock = new int[dimen][dimen];

		for (int i = 0; i < this.dimen; i++) {
			for (int j = 0; j < this.dimen; j++) {
				newBlock[i][j] = block[i][j];
			}
		}

		int temp = newBlock[i1][j1];
		newBlock[i1][j1] = newBlock[i2][j2];
		newBlock[i2][j2] = temp;

		return newBlock;
	}

	// 单元测试
	public static void main(String[] args) {

		In in = new In(args[0]);
		int dimen = in.readInt();

		int[][] initial = new int[dimen][dimen];

		for (int i = 0; i < dimen; i++) {
			for (int j = 0; j < dimen; j++) {
				initial[i][j] = in.readInt();
			}
		}

		Board node = new Board(initial);

		StdOut.println("原block：" + node.toString());
		StdOut.println("hamming结果：" + node.hamming());
		StdOut.println("manhattan结果：" + node.manhattan());
		StdOut.println("一次交换的block：" + node.twin());
		StdOut.println("neighbors:");

		Iterator<Board> it = node.neighbors().iterator();
		while (it.hasNext()) {
			StdOut.println(it.next());
		}
	}
}
