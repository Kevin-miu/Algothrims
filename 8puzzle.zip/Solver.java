import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {

	private boolean isSolvable;
	private SearchNode currentNode;

	// 定义一个私有的内部类search node
	// 由于优先队列Minpq使用到了CompareTo方法，所以必须实现Comparable接口
	private class SearchNode implements Comparable<SearchNode> {

		public Board board;
		public int move;
		public SearchNode preNode;
		public int priority;
		public boolean isInitParity;// 判断是原board和其twin

		// 定义初始的search node
		public SearchNode(Board bd, boolean initParity) {

			if (bd == null) {
				throw new IllegalArgumentException("null board!");
			}

			this.board = bd;
			this.move = 0;
			this.preNode = null;
			this.priority = this.board.manhattan();
			this.isInitParity = initParity;
		}

		// 定义初始之后的serach node
		public SearchNode(Board bd, SearchNode pre) {

			if (bd == null) {
				throw new IllegalArgumentException("null board!");
			}

			if (pre == null) {
				throw new IllegalArgumentException("null pre");
			}

			this.board = bd;
			this.preNode = pre;
			this.move = pre.move + 1;
			this.priority = this.move + this.board.manhattan();
			this.isInitParity = pre.isInitParity;

		}

		@Override
		public int compareTo(SearchNode o) {

			if (this.priority == o.priority) {
				return this.board.manhattan() - o.board.manhattan();
			} else {
				// 这里可以返回>0,=0,<0三种情况
				return this.priority - o.priority;
			}
		}

	}

	public Solver(Board initial) {

		if (initial == null) {
			throw new IllegalArgumentException("null initial!");
		}

		// A-star搜索方法
		MinPQ<SearchNode> pq = new MinPQ<>();
		pq.insert(new SearchNode(initial, true));
		pq.insert(new SearchNode(initial.twin(), false));

		while (true) {

			currentNode = pq.delMin();

			if (currentNode.board.isGoal()) {
				break;
			}

			for (Board b : currentNode.board.neighbors()) {
				if (currentNode.preNode == null || !b.equals(currentNode.preNode.board)) {
					pq.insert(new SearchNode(b, currentNode));
				}
			}
		}
		isSolvable = currentNode.isInitParity && currentNode.board.isGoal();

	}

	// 是否有解
	public boolean isSolvable() {
		return this.isSolvable;
	}

	// 为到达目标节点所移动的步长
	public int moves() {

		if (!isSolvable()) {
			return -1;
		} else {
			return currentNode.move;
		}

	}

	// 根据目标节点，往前遍历得到最优路径
	public Iterable<Board> solution() {

		if (!isSolvable()) {
			return null;
		}

		Stack<Board> path = new Stack<>();

		SearchNode node = currentNode;

		while (node != null) {
			path.push(node.board);
			node = node.preNode;
		}

		return path;
	}

	// 单元测试
	public static void main(String[] args) {

		// create initial board from file
		In in = new In(args[0]);
		int n = in.readInt();
		int[][] blocks = new int[n][n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				blocks[i][j] = in.readInt();
		Board initial = new Board(blocks);

		// solve the puzzle
		Solver solver = new Solver(initial);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
		}

	}
}
